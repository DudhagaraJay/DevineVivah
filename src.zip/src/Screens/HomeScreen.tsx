import { SafeAreaView, StyleSheet, Text, View } from 'react-native'
import React from 'react'
import { Color } from '../Theme'

const HomeScreen = () => {
  return (
    <SafeAreaView style={{backgroundColor: Color.white, flex: 1}}>
    
      <Text>HomeScreen</Text>
    </SafeAreaView>
  )
}

export default HomeScreen

const styles = StyleSheet.create({})