import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const ChatesScreen = () => {
  return (
    <View>
      <Text>ChatesScreen</Text>
    </View>
  )
}

export default ChatesScreen

const styles = StyleSheet.create({})