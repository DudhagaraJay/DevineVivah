import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const StoreScreen = () => {
  return (
    <View>
      <Text>StoreScreen</Text>
    </View>
  )
}

export default StoreScreen

const styles = StyleSheet.create({})