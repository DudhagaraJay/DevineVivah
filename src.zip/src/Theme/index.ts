export const Color = {
white: "#ffff",
orange: "#FF5A60",
inputBg: "#FAFAFA",
border: "#DEDEDE",
black: "#000000",
chatBg: "#8391A1",
placeholderText: "#4A4B4E",
darkBlack: "#1E232C"
}