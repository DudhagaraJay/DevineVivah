
import { StyleSheet } from "react-native";
import { FontSize } from "./FontSize";
import { Color } from ".";


export const Typography = StyleSheet.create({
    main_heading: {
       fontFamily: "Urbanist-Black",
       fontSize: FontSize.Font33,
        color: Color.black,
      },
      title:{
        fontFamily: "Urbanist-Medium",
        fontSize: FontSize.Font14,
         color: Color.black,
         fontWeight: "500"
      },
      small:{
        fontFamily: "Urbanist-Medium",
        fontSize: FontSize.Font16,
        fontWeight: "500"
      },
      smallTitle:{
      fontSize: FontSize.Font16,
      fontFamily: "Poppins-Medium",
      fontWeight: "500",
      letterSpacing: 0.5
      },
      tab:{
        fontSize: FontSize.Font12,
        fontFamily: "Poppins-Medium",
        fontWeight: "400",
        
        },
      body:{
        fontFamily: "Poppins-Medium",
        fontSize: FontSize.Font16,
        fontWeight: "400",
        letterSpacing: 1,
      }
})